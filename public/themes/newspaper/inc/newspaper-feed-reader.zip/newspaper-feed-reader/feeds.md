**Portland Press Herald**
* https://www.pressherald.com/feed/
* https://www.pressherald.com/american-journal/feed

**ABC 7 Chicago**
* https://abc7chicago.com/feed/

**Aljazeera**
* https://www.aljazeera.com/xml/rss/all.xml

**Teslarati**
* https://www.teslarati.com/feed/

**Times of Israel**
* https://www.timesofisrael.com/feed/

**Daily Mail**
* https://www.dailymail.co.uk/articles.rss

**Billboard**
* https://www.billboard.com/rss/

**Vox**
* https://www.vox.com/rss/index.xml

**Digital Trends**
* https://www.digitaltrends.com/feed

**BBCI**
* http://feeds.bbci.co.uk/sport/rss.xml

**Quartz**
* https://cms.qz.com/feed/

**Tom's guide**
* https://www.tomsguide.com/feeds/all

**The Guardian**
* https://www.theguardian.com/international/rss

**NY Times**
* https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml

**Politico**
* https://www.politico.com/rss/politicopicks.xml

**Newsweek**
* https://newsweek.ro/rss

**The Daily Beast**
* https://feeds.thedailybeast.com/rss/articles

**Google News**
* https://news.google.com/rss?hl=en-US&gl=US&ceid=US%3Aen&oc=11

**Yahoo!**
* https://news.yahoo.com/rss
* https://sports.yahoo.com/rss/

**NPR**
* https://feeds.npr.org/1002/rss.xml
* https://feeds.npr.org/1001/rss.xml
* https://feeds.npr.org/1039/rss.xml
* https://feeds.npr.org/1032/rss.xml
* https://feeds.npr.org/3/rss.xml
* https://feeds.npr.org/2/rss.xml
* https://feeds.npr.org/35/rss.xml

**Phys**
* https://phys.org/rss-feed
* https://phys.org/rss-feed/breaking
* https://phys.org/rss-feed/editorials

**Los Angeles**
* https://www.dailynews.com/feed

**Independent**
* https://www.independent.co.uk/rss

**Sporting News**
* http://www.sportingnews.com/us/rss

### Romania
**Film Now**
* https://www.filmnow.ro/rss
