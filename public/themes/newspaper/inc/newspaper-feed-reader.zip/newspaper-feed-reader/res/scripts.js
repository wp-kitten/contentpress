//<editor-fold desc="selectize-categories">
jQuery( function ($) {
    "use strict";
    $( '.cpfr-page-wrap .selectize-control' ).selectize( {
        create: false,
    } );
} );
//</editor-fold desc="selectize-categories">
